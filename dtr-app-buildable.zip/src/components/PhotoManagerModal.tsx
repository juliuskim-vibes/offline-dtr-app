import React, { useState, useMemo } from 'react';
import {
  X,
  Trash2,
  Images,
  CheckSquare,
  Square,
  AlertCircle,
  Calendar,
  CheckCircle2,
  ZoomIn,
} from 'lucide-react';
import { DayUiModel, getEntryPhotos } from '../types/dtr';

interface PhotoManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  monthTitle: string;
  daysList: DayUiModel[];
  onDeleteAllMonthPhotos: () => void;
  onDeleteDayPhotos: (dateStr: string) => void;
  onDeleteSpecificPhoto: (dateStr: string, photoIndex: number) => void;
  onDeleteSelectedDates: (dates: string[]) => void;
}

export const PhotoManagerModal: React.FC<PhotoManagerModalProps> = ({
  isOpen,
  onClose,
  monthTitle,
  daysList,
  onDeleteAllMonthPhotos,
  onDeleteDayPhotos,
  onDeleteSpecificPhoto,
  onDeleteSelectedDates,
}) => {
  // Days with at least 1 attached photo
  const daysWithPhotos = useMemo(() => {
    return daysList.filter((d) => {
      const photos = getEntryPhotos(d);
      return photos.length > 0;
    });
  }, [daysList]);

  // Total count of photos across all days in this month
  const totalPhotosCount = useMemo(() => {
    return daysWithPhotos.reduce((acc, d) => acc + getEntryPhotos(d).length, 0);
  }, [daysWithPhotos]);

  // Selected dates for batch deletion
  const [selectedDates, setSelectedDates] = useState<Set<string>>(new Set());
  // Lightbox preview for a clicked photo
  const [previewPhoto, setPreviewPhoto] = useState<{ url: string; date: string; index: number } | null>(null);

  if (!isOpen) return null;

  const allSelected =
    daysWithPhotos.length > 0 && selectedDates.size === daysWithPhotos.length;

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedDates(new Set());
    } else {
      setSelectedDates(new Set(daysWithPhotos.map((d) => d.date)));
    }
  };

  const toggleSelectDate = (date: string) => {
    setSelectedDates((prev) => {
      const next = new Set(prev);
      if (next.has(date)) {
        next.delete(date);
      } else {
        next.add(date);
      }
      return next;
    });
  };

  const handleDeleteSelected = () => {
    if (selectedDates.size === 0) return;
    const count = selectedDates.size;
    if (
      confirm(
        `Delete all attached proof photos for the ${count} selected day(s)? Daily activities and remarks will remain intact.`
      )
    ) {
      onDeleteSelectedDates(Array.from(selectedDates));
      setSelectedDates(new Set());
    }
  };

  const handleDeleteAll = () => {
    if (totalPhotosCount === 0) return;
    if (
      confirm(
        `Are you sure you want to delete ALL ${totalPhotosCount} attached proof photo(s) for ${monthTitle} in one click?\n\nNote: All daily activities, dates, and remarks will remain completely safe and untouched.`
      )
    ) {
      onDeleteAllMonthPhotos();
      setSelectedDates(new Set());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-3xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 transition-colors overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300 rounded-lg">
                <Images className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Attached Proof Photos Manager
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {monthTitle} · {totalPhotosCount} total {totalPhotosCount === 1 ? 'photo' : 'photos'} across {daysWithPhotos.length} {daysWithPhotos.length === 1 ? 'day' : 'days'}
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Informative Guidance Banner */}
        <div className="px-6 py-2.5 bg-blue-50/70 dark:bg-blue-950/30 border-b border-blue-100 dark:border-blue-900/50 flex items-center gap-2 text-xs text-blue-800 dark:text-blue-300">
          <AlertCircle className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
          <span>
            Safely delete attached proofs when rolling over to a new month or to free local storage. All daily accomplishment logs, hours, and remarks remain intact.
          </span>
        </div>

        {/* Toolbar with 1-Click Global Purge & Selective Actions */}
        {daysWithPhotos.length > 0 && (
          <div className="px-6 py-3 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={toggleSelectAll}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                {allSelected ? (
                  <CheckSquare className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400 dark:text-slate-500" />
                )}
                <span>{allSelected ? 'Deselect All' : 'Select All'}</span>
              </button>

              {selectedDates.size > 0 && (
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  ({selectedDates.size} selected)
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* Selective Delete Button */}
              {selectedDates.size > 0 && (
                <button
                  onClick={handleDeleteSelected}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-200 dark:border-amber-800 rounded-lg transition-colors shadow-2xs"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected ({selectedDates.size})</span>
                </button>
              )}

              {/* 1-Click Global Delete All Photos Button */}
              <button
                onClick={handleDeleteAll}
                title="Remove all photos for this month in one click"
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg transition-colors shadow-xs"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete All Photos ({totalPhotosCount})</span>
              </button>
            </div>
          </div>
        )}

        {/* Content Area: Photo Gallery by Day */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {daysWithPhotos.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500">
                <Images className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  No Proof Photos for {monthTitle}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                  There are currently no photos attached to any day in this month. Camera snapshots or image uploads will be listed here.
                </p>
              </div>
            </div>
          ) : (
            daysWithPhotos.map((day) => {
              const photos = getEntryPhotos(day);
              const isSelected = selectedDates.has(day.date);

              return (
                <div
                  key={day.date}
                  className={`rounded-xl border transition-all p-4 ${
                    isSelected
                      ? 'border-blue-400 dark:border-blue-600 bg-blue-50/40 dark:bg-blue-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs'
                  }`}
                >
                  {/* Day Header */}
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => toggleSelectDate(day.date)}
                        className="text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400 dark:text-slate-600" />
                        )}
                      </button>

                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded">
                          Day {String(day.dayOfMonth).padStart(2, '0')}
                        </span>
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {day.fullDayName}
                        </span>
                        <span className="text-slate-300 dark:text-slate-700">·</span>
                        <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                          {day.date}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (
                          confirm(
                            `Delete ${photos.length} photo(s) for Day ${day.dayOfMonth} (${day.date})?`
                          )
                        ) {
                          onDeleteDayPhotos(day.date);
                        }
                      }}
                      className="flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/40 px-2 py-1 rounded transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Day's Photos</span>
                    </button>
                  </div>

                  {/* Day Activity preview */}
                  {day.activities && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 italic mb-3 line-clamp-1 pl-7">
                      "{day.activities}"
                    </p>
                  )}

                  {/* Photos Grid for this Day */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 pl-7">
                    {photos.map((photoUrl, pIdx) => (
                      <div
                        key={pIdx}
                        className="group relative rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 aspect-video flex items-center justify-center shadow-2xs"
                      >
                        <img
                          src={photoUrl}
                          alt={`Proof ${pIdx + 1}`}
                          className="w-full h-full object-cover"
                        />

                        {/* Photo overlay badge */}
                        <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 bg-black/75 backdrop-blur-xs text-[10px] font-mono text-white rounded">
                          #{pIdx + 1}
                        </div>

                        {/* Hover action overlay */}
                        <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
                          <button
                            type="button"
                            onClick={() =>
                              setPreviewPhoto({
                                url: photoUrl,
                                date: day.date,
                                index: pIdx + 1,
                              })
                            }
                            title="Preview large image"
                            className="p-1.5 bg-white/90 hover:bg-white text-slate-900 rounded-md transition-colors shadow-xs"
                          >
                            <ZoomIn className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (
                                confirm(
                                  `Delete photo #${pIdx + 1} for ${day.date}?`
                                )
                              ) {
                                onDeleteSpecificPhoto(day.date, pIdx);
                              }
                            }}
                            title="Delete this photo"
                            className="p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors shadow-xs"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {totalPhotosCount > 0 ? (
              <>
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  {totalPhotosCount}
                </span>{' '}
                proof photo(s) ready for export or deletion
              </>
            ) : (
              'All clean'
            )}
          </span>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>

      {/* Lightbox Photo Preview Modal */}
      {previewPhoto && (
        <div
          className="fixed inset-0 z-60 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setPreviewPhoto(null)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] bg-slate-950 rounded-xl overflow-hidden shadow-2xl p-2 border border-slate-700"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-3 border-b border-slate-800 text-white text-xs">
              <span className="font-mono">
                Date: {previewPhoto.date} · Photo #{previewPhoto.index}
              </span>
              <button
                onClick={() => setPreviewPhoto(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-2 max-h-[75vh] flex items-center justify-center overflow-auto">
              <img
                src={previewPhoto.url}
                alt="Enlarged proof"
                className="max-h-[72vh] max-w-full object-contain rounded"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
