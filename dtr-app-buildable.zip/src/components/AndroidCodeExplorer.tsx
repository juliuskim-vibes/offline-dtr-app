import React, { useState } from 'react';
import {
  Copy,
  Check,
  Download,
  FileCode,
  FolderTree,
  Terminal,
  ShieldCheck,
  Layers,
  Sparkles,
} from 'lucide-react';
import { ANDROID_FILES, AndroidCodeFile, downloadAndroidProjectZip } from '../utils/androidCodeFiles';
import { downloadBlob } from '../utils/docxExport';

export const AndroidCodeExplorer: React.FC = () => {
  const [selectedFileId, setSelectedFileId] = useState<string>('build_gradle_app');
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const selectedFile = ANDROID_FILES.find((f) => f.id === selectedFileId) || ANDROID_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingleFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    downloadBlob(blob, selectedFile.name);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  // Group files by category
  const categories: { label: string; key: AndroidCodeFile['category'] }[] = [
    { label: 'Build & Config', key: 'build' },
    { label: 'Room Database Layer', key: 'database' },
    { label: 'Camera & Exporter Utils', key: 'util' },
    { label: 'UI & Jetpack Compose', key: 'ui' },
    { label: 'Manifest & XML', key: 'config' },
  ];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <FolderTree className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Android Source Code Explorer
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Complete, offline-first production architecture using Kotlin, Jetpack Compose Material 3, Room 2.6.1, Coil, and Apache POI 5.2.5.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors shadow-xs disabled:opacity-60 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isZipping ? 'Bundling ZIP...' : 'Download Full Project (.ZIP)'}</span>
          </button>
        </div>
      </div>

      {/* Main Code Viewport Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: File Tree Navigation */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3">
              Project Structure
            </h3>

            <div className="space-y-4">
              {categories.map((cat) => {
                const files = ANDROID_FILES.filter((f) => f.category === cat.key);
                if (files.length === 0) return null;

                return (
                  <div key={cat.key} className="space-y-1">
                    <p className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 px-2">
                      {cat.label}
                    </p>
                    <div className="space-y-0.5">
                      {files.map((file) => {
                        const isSelected = file.id === selectedFileId;
                        return (
                          <button
                            key={file.id}
                            onClick={() => setSelectedFileId(file.id)}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-mono transition-colors text-left ${
                              isSelected
                                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300 font-semibold'
                                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              <FileCode className="w-3.5 h-3.5 shrink-0 opacity-70" />
                              <span className="truncate">{file.name}</span>
                            </div>
                            <span className="text-[10px] uppercase font-sans text-slate-400 dark:text-slate-500 shrink-0 ml-1">
                              {file.language}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Principal Android Notes */}
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs space-y-2.5">
            <div className="flex items-center gap-2 font-semibold text-slate-900 dark:text-slate-100">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Principal Architectural Decisions</span>
            </div>
            <ul className="space-y-1.5 text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed list-disc list-inside">
              <li>
                <strong className="text-slate-800 dark:text-slate-200">Packaging Exclusions:</strong> Apache POI 5.2.5 has conflicting schemas; resolved via <code className="text-blue-600 dark:text-blue-400">packaging.resources.excludes</code>.
              </li>
              <li>
                <strong className="text-slate-800 dark:text-slate-200">Scoped Storage (Android 10+):</strong> Uses MediaStore for public Downloads with legacy fallback.
              </li>
              <li>
                <strong className="text-slate-800 dark:text-slate-200">Private Photos:</strong> Camera images stored in <code className="text-blue-600 dark:text-blue-400">context.filesDir</code> to avoid external storage permission prompts.
              </li>
              <li>
                <strong className="text-slate-800 dark:text-slate-200">Flow Observation:</strong> Room queries reactively update Compose when entries change.
              </li>
            </ul>
          </div>
        </div>

        {/* Right Column: Code Viewer */}
        <div className="lg:col-span-8 flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
          {/* File Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {selectedFile.path}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                {selectedFile.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadSingleFile}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Code Body with line numbers */}
          <div className="relative overflow-x-auto p-4 bg-slate-950 text-slate-100 font-mono text-xs leading-relaxed max-h-[640px] overflow-y-auto">
            <pre className="grid grid-cols-[auto_1fr] gap-4">
              <span className="text-slate-600 select-none text-right font-mono pr-2 border-r border-slate-800">
                {selectedFile.content
                  .split('\n')
                  .map((_, i) => (
                    <span key={i} className="block text-[11px]">
                      {i + 1}
                    </span>
                  ))}
              </span>
              <code className="text-slate-200 overflow-x-auto text-[11px] whitespace-pre">
                {selectedFile.content}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
