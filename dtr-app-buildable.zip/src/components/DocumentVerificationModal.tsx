import React, { useState, useRef, useMemo } from 'react';
import {
  X,
  FileDown,
  Printer,
  Eye,
  ZoomIn,
  ZoomOut,
  Maximize2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  FileText,
  Camera,
  Layers,
} from 'lucide-react';
import { DayUiModel, InstitutionalMetadata, getEntryPhotos } from '../types/dtr';

interface DocumentVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  daysList: DayUiModel[];
  metadata: InstitutionalMetadata;
  monthTitle: string;
  onExportDocx: () => void;
  isExporting: boolean;
}

export const DocumentVerificationModal: React.FC<DocumentVerificationModalProps> = ({
  isOpen,
  onClose,
  daysList,
  metadata,
  monthTitle,
  onExportDocx,
  isExporting,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100); // 70% to 140%
  const [activePage, setActivePage] = useState<number>(1);
  const containerRef = useRef<HTMLDivElement>(null);

  // Extract all photo items across the month
  const photoItems = useMemo(() => {
    const items: Array<{
      date: string;
      dayOfMonth: number;
      fullDayName: string;
      activities: string;
      photoUrl: string;
      photoIndex: number;
      totalForDay: number;
    }> = [];

    daysList.forEach((day) => {
      const photos = getEntryPhotos(day);
      photos.forEach((photoUrl, photoIndex) => {
        items.push({
          date: day.date,
          dayOfMonth: day.dayOfMonth,
          fullDayName: day.fullDayName,
          activities: day.activities,
          photoUrl,
          photoIndex,
          totalForDay: photos.length,
        });
      });
    });

    return items;
  }, [daysList]);

  // Total pages = Page 1 (Table 1-23) + Page 2 (Table 24-end + Signatures) + Attachment Pages
  const totalPages = 2 + photoItems.length;

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 15, 145));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 15, 70));
  };

  const handleResetZoom = () => {
    setZoomLevel(100);
  };

  const scrollToPage = (pageNum: number) => {
    setActivePage(pageNum);
    const element = document.getElementById(`doc-page-${pageNum}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      {/* Explicit Print Rules for Folio (8.5 x 13 in) */}
      <style>{`
        @media print {
          @page {
            size: 8.5in 13in;
            margin: 0.75in;
          }
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
        }
      `}</style>

      {/* ================= MODAL TOP CONTROL BAR ================= */}
      <header className="shrink-0 flex items-center justify-between gap-4 px-6 py-3.5 bg-slate-900 border-b border-slate-800 text-white shadow-md print:hidden">
        {/* Left: Title & Badge */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600/20 text-blue-400 rounded-lg border border-blue-500/30">
            <Eye className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight text-white">
                8.5 × 13 Folio Document Verification
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-bold font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded">
                Read-Only Preview
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold font-mono uppercase bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded">
                Folio (8.5 × 13 in)
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulating final Microsoft Word (.docx) & Institutional layout for {monthTitle}
            </p>
          </div>
        </div>

        {/* Center: Page Jump Tabs & Zoom Controls */}
        <div className="hidden lg:flex items-center gap-3">
          {/* Quick Page Jump Pills */}
          <div className="flex items-center gap-1 px-1 py-1 bg-slate-950 rounded-lg border border-slate-800 text-xs font-medium">
            <button
              onClick={() => scrollToPage(1)}
              className={`px-2.5 py-1 rounded transition-colors ${
                activePage === 1 ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Page 1: Days 1–23
            </button>
            <button
              onClick={() => scrollToPage(2)}
              className={`px-2.5 py-1 rounded transition-colors ${
                activePage === 2 ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Page 2: Days 24–End & Signatures
            </button>
            {photoItems.length > 0 && (
              <button
                onClick={() => scrollToPage(3)}
                className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 ${
                  activePage >= 3 ? 'bg-purple-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Camera className="w-3 h-3" />
                <span>Annex: Photos ({photoItems.length})</span>
              </button>
            )}
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 px-2 py-1 bg-slate-950 rounded-lg border border-slate-800 text-xs font-mono">
            <button
              onClick={handleZoomOut}
              disabled={zoomLevel <= 70}
              className="p-1 text-slate-400 hover:text-white disabled:opacity-30 transition-colors"
              title="Zoom out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="w-12 text-center text-slate-200">{zoomLevel}%</span>
            <button
              onClick={handleZoomIn}
              disabled={zoomLevel >= 145}
              className="p-1 text-slate-400 hover:text-white disabled:opacity-30 transition-colors"
              title="Zoom in"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleResetZoom}
              className="ml-1 p-1 text-slate-400 hover:text-white transition-colors"
              title="Reset Zoom to 100%"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Right: Actions & Close */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrint}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors shadow-xs"
            title="Print Folio 8.5x13 document"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Folio</span>
          </button>

          <button
            onClick={onExportDocx}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg transition-colors shadow-xs disabled:opacity-60"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Generating...' : 'Download .DOCX'}</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-1"
            title="Close Preview Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* ================= DOCUMENT VIEWER AREA ================= */}
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto overflow-x-auto p-4 sm:p-8 bg-slate-950 flex flex-col items-center gap-10"
      >
        {/* Verification banner in viewer */}
        <div className="w-full max-w-[850px] p-3 rounded-lg bg-blue-900/30 border border-blue-500/30 text-blue-200 text-xs flex items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
            <span>
              <strong>Read-Only Pre-Flight Inspection:</strong> Verify institutional layout, weekend auto-tags, leave entries without remarks, and signatories.
            </span>
          </div>
          <span className="shrink-0 font-mono text-[11px] text-blue-300">
            Total Pages: {totalPages}
          </span>
        </div>

        {/* Dynamic Zoom Container */}
        <div
          style={{
            transform: `scale(${zoomLevel / 100})`,
            transformOrigin: 'top center',
            transition: 'transform 0.15s ease-out',
          }}
          className="flex flex-col items-center gap-12"
        >
          {/* ================= PAGE 1: DAYS 1 TO 23 ================= */}
          <div
            id="doc-page-1"
            className="w-[816px] min-h-[1248px] bg-white text-slate-900 p-12 shadow-2xl rounded-sm border border-slate-200 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none [font-family:'Times_New_Roman',Times,serif] select-none"
          >
            {/* Page Tag in Modal */}
            <div className="text-right text-[11px] text-slate-400 font-mono mb-4 print:hidden">
              Page 1 of {totalPages} · [Folio 8.5 × 13 in]
            </div>

            {/* Institution Header */}
            <div className="text-center space-y-1 mb-6">
              <p className="text-xs text-slate-800">
                Republic of the Philippines
              </p>
              <h1 className="text-sm font-bold text-slate-950 uppercase tracking-wide">
                {metadata.agencyOrInstitution}
              </h1>
              <div className="pt-2 space-y-0.5">
                <h2 className="text-xs font-bold text-slate-950 tracking-wide uppercase">
                  ACCOMPLISHMENT REPORT
                </h2>
                <p className="text-xs font-bold text-slate-900 tracking-wide uppercase">
                  MONTH OF {monthTitle.toUpperCase()}
                </p>
              </div>
            </div>

            {/* Sub-Header: Name & Position */}
            <div className="flex justify-between items-center text-xs mb-3 font-serif">
              <div>
                <span className="font-bold text-slate-900">Name: </span>
                <span className="text-slate-800 uppercase font-medium">{metadata.employeeName}</span>
              </div>
              <div>
                <span className="font-bold text-slate-900">Position: </span>
                <span className="text-slate-800 font-medium">{metadata.employeePosition}</span>
              </div>
            </div>

            {/* 3-Column Table: Part 1 (Days 1 to 23) */}
            <div className="border border-slate-950 overflow-hidden">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-[#BDD7EE] text-slate-950 font-bold border-b border-slate-950">
                    <th className="py-1 px-2 text-center border-r border-slate-950 w-14 font-bold">
                      Date
                    </th>
                    <th className="py-1 px-3 text-center border-r border-slate-950 font-bold">
                      Activities
                    </th>
                    <th className="py-1 px-2 text-center border-slate-950 w-28 font-bold">
                      Remarks
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {daysList.slice(0, 23).map((day) => {
                    const isSat = day.isSaturday;
                    const isSun = day.isSunday;
                    let activitiesText = day.activities.trim();
                    let remarksText = day.remarks.trim();
                    const isLeave = day.status === 'Leave' || activitiesText.toLowerCase().includes('leave');

                    if (isSat) {
                      activitiesText = 'SATURDAY';
                      remarksText = '';
                    } else if (isSun) {
                      activitiesText = 'SUNDAY';
                      remarksText = '';
                    } else if (isLeave) {
                      if (!activitiesText) activitiesText = 'Leave';
                      remarksText = ''; // Strictly no remark for leave
                    } else {
                      if (!remarksText && activitiesText) {
                        remarksText = 'Accomplished';
                      }
                    }

                    return (
                      <tr
                        key={day.date}
                        className="border-b border-slate-900 last:border-b-0"
                      >
                        <td className="py-1 px-2 text-center border-r border-slate-900 text-xs">
                          <span className={isSat || isSun ? 'font-bold' : ''}>
                            {day.dayOfMonth}
                          </span>
                        </td>
                        <td className="py-1 px-3 text-left border-r border-slate-900 text-slate-900 leading-tight">
                          <span className={isSat || isSun ? 'font-bold' : ''}>
                            {activitiesText}
                          </span>
                        </td>
                        <td className="py-1 px-2 text-center text-slate-900 whitespace-nowrap text-xs">
                          {remarksText}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* ================= PAGE 2: DAYS 24 TO END + SIGNATORIES ================= */}
          <div
            id="doc-page-2"
            className="w-[816px] min-h-[1248px] bg-white text-slate-900 p-12 shadow-2xl rounded-sm border border-slate-200 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:break-before-page [font-family:'Times_New_Roman',Times,serif] select-none"
          >
            {/* Page Tag in Modal */}
            <div className="text-right text-[11px] text-slate-400 font-mono mb-4 print:hidden">
              Page 2 of {totalPages} · [Folio 8.5 × 13 in]
            </div>

            {/* 3-Column Table: Part 2 (Days 24 to End of Month) */}
            <div className="border border-slate-950 overflow-hidden mb-12">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-[#BDD7EE] text-slate-950 font-bold border-b border-slate-950">
                    <th className="py-1 px-2 text-center border-r border-slate-950 w-14 font-bold">
                      Date
                    </th>
                    <th className="py-1 px-3 text-center border-r border-slate-950 font-bold">
                      Activities
                    </th>
                    <th className="py-1 px-2 text-center border-slate-950 w-28 font-bold">
                      Remarks
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {daysList.slice(23).map((day) => {
                    const isSat = day.isSaturday;
                    const isSun = day.isSunday;
                    let activitiesText = day.activities.trim();
                    let remarksText = day.remarks.trim();
                    const isLeave = day.status === 'Leave' || activitiesText.toLowerCase().includes('leave');

                    if (isSat) {
                      activitiesText = 'SATURDAY';
                      remarksText = '';
                    } else if (isSun) {
                      activitiesText = 'SUNDAY';
                      remarksText = '';
                    } else if (isLeave) {
                      if (!activitiesText) activitiesText = 'Leave';
                      remarksText = ''; // Strictly no remark for leave
                    } else {
                      if (!remarksText && activitiesText) {
                        remarksText = 'Accomplished';
                      }
                    }

                    return (
                      <tr
                        key={day.date}
                        className="border-b border-slate-900 last:border-b-0"
                      >
                        <td className="py-1 px-2 text-center border-r border-slate-900 text-xs">
                          <span className={isSat || isSun ? 'font-bold' : ''}>
                            {day.dayOfMonth}
                          </span>
                        </td>
                        <td className="py-1 px-3 text-left border-r border-slate-900 text-slate-900 leading-tight">
                          <span className={isSat || isSun ? 'font-bold' : ''}>
                            {activitiesText}
                          </span>
                        </td>
                        <td className="py-1 px-2 text-center text-slate-900 whitespace-nowrap text-xs">
                          {remarksText}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Signatories Section (directly below table matching template page 2) */}
            <div className="grid grid-cols-2 gap-10 pt-4 font-serif">
              {/* Prepared by */}
              <div>
                <p className="text-xs text-slate-800 mb-12">Prepared by:</p>
                <p className="text-xs font-bold text-slate-950 uppercase">
                  {metadata.employeeName || '[INPUT NAME]'}
                </p>
                <p className="text-xs text-slate-700">
                  {metadata.employeePosition || '[INPUT DESIGNATION]'}
                </p>
              </div>

              {/* Verified by (Immediate Head) */}
              <div>
                <p className="text-xs text-slate-800 mb-12">Verified by:</p>
                <p className="text-xs font-bold text-slate-950 uppercase">
                  {metadata.verifiedByName || '[INPUT NAME]'}
                </p>
                <p className="text-xs text-slate-700">
                  {metadata.verifiedByPosition || '[INPUT DESIGNATION]'}
                </p>
              </div>
            </div>

            {/* Center Bottom: Approved by (Director) */}
            <div className="flex flex-col items-center justify-center text-center mt-16 font-serif">
              <p className="text-xs text-slate-800 mb-12">Approved by:</p>
              <p className="text-xs font-bold text-slate-950 uppercase">
                {metadata.approvedByName || '[INPUT NAME]'}
              </p>
              <p className="text-xs text-slate-700">
                {metadata.approvedByPosition || '[INPUT DESIGNATION]'}
              </p>
            </div>
          </div>

          {/* ================= ANNEX PAGES: ATTACHMENTS FOR VERIFICATION ================= */}
          {photoItems.map((item, pIdx) => {
            const pageNumber = pIdx + 3;

            return (
              <div
                key={`${item.date}-${item.photoIndex}-${pIdx}`}
                id={`doc-page-${pageNumber}`}
                className="w-[816px] min-h-[1248px] bg-white text-slate-900 p-12 shadow-2xl rounded-sm border border-slate-200 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:break-before-page [font-family:'Times_New_Roman',Times,serif] select-none"
              >
                {/* Print/Preview Page Indicator */}
                <div className="text-right text-[11px] text-slate-400 font-mono mb-4 print:hidden">
                  Page {pageNumber} of {totalPages} · [Folio 8.5 × 13 in Attachment {pIdx + 1} of {photoItems.length}]
                </div>

                {/* Header matching template */}
                <div className="text-center mb-6 pt-4">
                  <h2 className="text-sm font-bold text-slate-950 uppercase tracking-wide">
                    ATTACHMENTS FOR VERIFICATION
                  </h2>
                </div>

                {/* Inline Date & Activity line matching template */}
                <div className="mb-6 text-xs text-slate-900 leading-relaxed">
                  <span className="font-bold">Date: </span>
                  <span>
                    {item.date} ({item.fullDayName.toUpperCase()})
                    {item.totalForDay > 1 ? ` (Photo ${item.photoIndex + 1} of ${item.totalForDay})` : ''}
                  </span>
                  <span className="mx-2 font-bold">   Activity: </span>
                  <span>{item.activities || 'Official duty logged'}</span>
                </div>

                {/* Large, Clear Centered Photo Frame */}
                <div className="w-full h-[640px] rounded-sm border border-slate-400 bg-slate-950 flex items-center justify-center overflow-hidden p-3 shadow-xs">
                  <img
                    src={item.photoUrl}
                    alt={`Attachment for ${item.date}`}
                    className="max-h-full max-w-full w-auto h-auto object-contain rounded-xs"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
