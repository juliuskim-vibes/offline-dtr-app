import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, Image as ImageIcon, Trash2, Plus, Video, RefreshCw } from 'lucide-react';
import { DayUiModel, getEntryPhotos } from '../types/dtr';

interface DailyEntryModalProps {
  day: DayUiModel | null;
  onClose: () => void;
  onSave: (
    date: string,
    dayOfMonth: number,
    activities: string,
    remarks: string,
    status: 'Accomplishment' | 'Accomplished' | 'Leave' | 'Official Travel' | 'Weekend',
    photoPath: string | null,
    photos?: string[]
  ) => void;
}

export const DailyEntryModal: React.FC<DailyEntryModalProps> = ({ day, onClose, onSave }) => {
  if (!day) return null;

  const [activities, setActivities] = useState(day.activities);
  const [remarks, setRemarks] = useState(day.remarks);
  const [status, setStatus] = useState<DayUiModel['status']>(day.status);
  
  // Multiple photos state (initialized from existing entry photos)
  const [photoUrls, setPhotoUrls] = useState<string[]>(() => getEntryPhotos(day));

  // Live Camera state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop camera when closing
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      setIsCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: unknown) {
      console.warn('Camera access unavailable:', err);
      setCameraError('Camera access unavailable. You can upload an image or attach a sample proof photo.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    // Scale down to max 640 width to preserve high clarity while keeping storage compact
    const maxDim = 640;
    let w = video.videoWidth || 640;
    let h = video.videoHeight || 480;
    if (w > maxDim || h > maxDim) {
      if (w > h) {
        h = Math.round((h * maxDim) / w);
        w = maxDim;
      } else {
        w = Math.round((w * maxDim) / h);
        h = maxDim;
      }
    }
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, w, h);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.65);
      setPhotoUrls((prev) => [...prev, dataUrl]);
      stopCamera();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const rawUrl = event.target?.result as string;
        if (!rawUrl) return;

        // Downscale image via offscreen canvas to keep storage size small (<50KB)
        const img = new Image();
        img.onload = () => {
          const maxDim = 720;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, w, h);
            const compressed = canvas.toDataURL('image/jpeg', 0.65);
            setPhotoUrls((prev) => [...prev, compressed]);
          } else {
            setPhotoUrls((prev) => [...prev, rawUrl]);
          }
        };
        img.src = rawUrl;
      };
      reader.readAsDataURL(file);
    });

    // Reset input value so the same file can be re-selected if desired
    e.target.value = '';
  };

  const attachSampleProof = () => {
    // Generate a lightweight, crisp canvas placeholder proof
    const canvas = document.createElement('canvas');
    canvas.width = 360;
    canvas.height = 220;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 360, 220);

      const grad = ctx.createLinearGradient(0, 0, 360, 220);
      grad.addColorStop(0, '#1e3a8a');
      grad.addColorStop(1, '#0f766e');
      ctx.fillStyle = grad;
      ctx.fillRect(10, 10, 340, 200);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('ATTACHMENTS FOR VERIFICATION', 24, 40);

      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(24, 52, 180, 22);
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 10px monospace';
      ctx.fillText(`DATE TAG: ${day.date}`, 30, 67);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = '10px monospace';
      ctx.fillText(`STATUS: ${status.toUpperCase()}`, 24, 100);
      ctx.fillText(`PROOF #${photoUrls.length + 1} · CAMERA SENSOR`, 24, 120);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '9px sans-serif';
      ctx.fillText('Official Photographic Evidence Attachment', 24, 180);

      const sampleUrl = canvas.toDataURL('image/jpeg', 0.6);
      setPhotoUrls((prev) => [...prev, sampleUrl]);
    }
  };

  const removePhoto = (indexToRemove: number) => {
    setPhotoUrls((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleMarkLeave = () => {
    setActivities('Leave');
    setRemarks(''); // If there is leave there should be no remark
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-slate-900 dark:text-white">
                Day {day.dayOfMonth} · {day.fullDayName}
              </span>
              {day.isWeekend && (
                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  Weekend
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">
              {day.date} · Institutional Daily Time Record
            </p>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-5 space-y-5">
          {/* 1. Workflow Status (Standardized to 'Accomplishment' only) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Workflow Status
              </label>
              <button
                type="button"
                onClick={handleMarkLeave}
                className="text-xs text-amber-600 dark:text-amber-400 hover:underline font-medium"
              >
                Mark as On Leave (No remark)
              </button>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 px-3.5 py-2 text-xs font-bold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-300 dark:border-blue-700 rounded-lg flex items-center justify-between shadow-2xs">
                <span>Accomplishment</span>
                <span className="text-[10px] font-mono uppercase bg-blue-600 text-white px-2 py-0.5 rounded-full">
                  Standard Status
                </span>
              </div>
            </div>
          </div>

          {/* 2. Activities Field */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Activities Undertaken / Accomplishments
              </label>
              <button
                type="button"
                onClick={() => {
                  setActivities(
                    'Conducted 3-hour laboratory lecture on Mobile Application Development and SQLite Room persistence.'
                  );
                  if (!remarks) setRemarks('Accomplished');
                }}
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
              >
                Insert sample task
              </button>
            </div>
            <textarea
              rows={4}
              value={activities}
              onChange={(e) => {
                const val = e.target.value;
                setActivities(val);
                // If user enters 'Leave', automatically ensure remarks is empty
                if (val.trim().toLowerCase() === 'leave') {
                  setRemarks('');
                }
              }}
              placeholder={
                day.isWeekend
                  ? 'Optional: Log weekend tasks or leave empty for default weekend tag...'
                  : 'Describe specific tasks, lecture hours, laboratory modules, or meetings...'
              }
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 outline-none transition-colors"
            />
          </div>

          {/* 3. Remarks (Accomplished, Ongoing, or No Remark for Leave) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Remarks
              </label>
              {activities.trim().toLowerCase() === 'leave' && (
                <span className="text-[11px] text-amber-600 dark:text-amber-400 italic">
                  Leave entry: No remark required
                </span>
              )}
            </div>

            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Select 'Accomplished', 'Ongoing', 'WFH', 'Official Travel', or leave blank"
              className="w-full px-3.5 py-2 text-sm bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:text-slate-100 outline-none transition-colors"
            />

            {/* Quick Action Buttons for Remarks */}
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => setRemarks('Accomplished')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                  remarks === 'Accomplished'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                    : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                }`}
              >
                ✓ Accomplished
              </button>

              <button
                type="button"
                onClick={() => setRemarks('Ongoing')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                  remarks === 'Ongoing'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                    : 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800 hover:bg-blue-100'
                }`}
              >
                ⏳ Ongoing
              </button>

              <button
                type="button"
                onClick={() => setRemarks('WFH')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                  remarks === 'WFH'
                    ? 'bg-purple-600 text-white border-purple-600 shadow-2xs'
                    : 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800 hover:bg-purple-100'
                }`}
              >
                🏠 WFH
              </button>

              <button
                type="button"
                onClick={() => setRemarks('Official Travel')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                  remarks === 'Official Travel'
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                    : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100'
                }`}
              >
                ✈️ Official Travel
              </button>

              <button
                type="button"
                onClick={() => setRemarks('')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                  remarks === ''
                    ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-600 font-semibold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
                }`}
              >
                No Remark (Leave / Blank)
              </button>
            </div>
          </div>

          {/* 4. Photographic Proof & Camera Section (Attachments for Verification) */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                  Attachments for Verification
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Each photo gets 1 dedicated full page in the exported document.
                </p>
              </div>
              <span className="px-2 py-0.5 text-xs font-mono font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-md border border-slate-200 dark:border-slate-700">
                {photoUrls.length} {photoUrls.length === 1 ? 'photo' : 'photos'}
              </span>
            </div>

            {/* List of Attached Photos */}
            {photoUrls.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {photoUrls.map((url, idx) => (
                  <div
                    key={idx}
                    className="relative group rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-950 flex flex-col"
                  >
                    <div className="relative h-36 bg-slate-900 flex items-center justify-center overflow-hidden">
                      <img
                        src={url}
                        alt={`Attachment ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2 py-0.5 bg-black/70 backdrop-blur-xs text-white text-[10px] font-bold font-mono rounded">
                        Photo {idx + 1}
                      </span>
                      <button
                        type="button"
                        onClick={() => removePhoto(idx)}
                        className="absolute top-2 right-2 p-1.5 bg-red-600/90 hover:bg-red-600 text-white rounded-md shadow-xs transition-colors"
                        title="Delete this photo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="p-2 bg-white dark:bg-slate-900 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                      <span>Dedicated Page {idx + 1}</span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-medium">Ready</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Active Live Camera View */}
            {isCameraActive && (
              <div className="relative rounded-lg overflow-hidden border border-slate-300 dark:border-slate-700 bg-black">
                <video
                  ref={videoRef}
                  playsInline
                  autoPlay
                  className="w-full h-52 object-cover"
                />
                <div className="absolute bottom-3 inset-x-0 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-medium text-xs shadow-lg flex items-center gap-1.5 transition-colors"
                  >
                    <Camera className="w-4 h-4" />
                    Snap Photo
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-3 py-2 bg-slate-800/80 hover:bg-slate-800 text-white rounded-full text-xs transition-colors"
                  >
                    Cancel Camera
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons to Add Photo / Add Another Photo */}
            {!isCameraActive && (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={startCamera}
                    className="flex-1 min-w-[130px] flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 border border-blue-200 dark:border-blue-800 rounded-lg transition-colors shadow-2xs"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{photoUrls.length > 0 ? '+ Camera Photo' : 'Launch Camera'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 min-w-[130px] flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors shadow-2xs"
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>{photoUrls.length > 0 ? '+ Upload Another Photo' : 'Upload Photo'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={attachSampleProof}
                    className="flex-1 min-w-[130px] flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/50 hover:bg-purple-100 dark:hover:bg-purple-900/50 border border-purple-200 dark:border-purple-800 rounded-lg transition-colors shadow-2xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Sample Proof</span>
                  </button>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />

                {cameraError && (
                  <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                    {cameraError}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              stopCamera();
              const isLeave = activities.trim().toLowerCase() === 'leave';
              const finalStatus: DayUiModel['status'] = isLeave
                ? 'Leave'
                : day.isWeekend && !activities.trim()
                ? 'Weekend'
                : 'Accomplishment';
              const finalRemarks = isLeave ? '' : remarks;
              onSave(
                day.date,
                day.dayOfMonth,
                activities,
                finalRemarks,
                finalStatus,
                photoUrls[0] || null,
                photoUrls
              );
            }}
            className="px-5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors shadow-xs"
          >
            Save Record
          </button>
        </div>
      </div>
    </div>
  );
};
