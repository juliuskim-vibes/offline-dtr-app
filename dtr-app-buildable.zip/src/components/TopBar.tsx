import React from 'react';
import { FileDown, Download, Sparkles, Moon, Sun, User, NotebookPen, Eye } from 'lucide-react';

interface TopBarProps {
  activeTab: 'generator' | 'preview' | 'profile' | 'code' | 'architecture';
  setActiveTab: (tab: 'generator' | 'preview' | 'profile' | 'code' | 'architecture') => void;
  onExportDocx: () => void;
  onDownloadProjectZip: () => void;
  isExporting: boolean;
  isDark: boolean;
  toggleDark: () => void;
  employeeName: string;
  onEmployeeNameChange: (name: string) => void;
  onOpenVerificationModal?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onExportDocx,
  onDownloadProjectZip,
  isExporting,
  isDark,
  toggleDark,
  employeeName,
  onEmployeeNameChange,
  onOpenVerificationModal,
}) => {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-8 px-6 py-3.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Zone 1: Single text wordmark & Name Inputer */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('generator');
          }}
          className="inline-flex items-center gap-2 text-base font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
        >
          <NotebookPen className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
          <span>NEMSU-SM DTR Accomplishment Journal</span>
        </a>
        <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-lg text-xs transition-colors">
          <User className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
          <input
            type="text"
            value={employeeName}
            onChange={(e) => onEmployeeNameChange(e.target.value)}
            placeholder="Employee Name..."
            aria-label="Employee Name"
            className="w-36 md:w-44 bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 uppercase outline-none"
            title="Employee Name for DTR & Accomplishment Report"
          />
        </span>
      </div>

      {/* Zone 2: Single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-5 text-sm font-medium">
        <button
          onClick={() => setActiveTab('generator')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'generator'
              ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Live Generator
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'preview'
              ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Document Preview
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'profile'
              ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Profile & Signatories
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'code'
              ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Android Source Code
        </button>
        <button
          onClick={() => setActiveTab('architecture')}
          className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
            activeTab === 'architecture'
              ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Architecture
        </button>
      </nav>

      {/* Zone 3: Primary Action & Controls */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={toggleDark}
          title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <button
          onClick={onDownloadProjectZip}
          title="Download ready-to-open Android Studio project ZIP"
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Android Project (.zip)</span>
        </button>

        {onOpenVerificationModal && (
          <button
            onClick={onOpenVerificationModal}
            title="Inspect 8.5x13 Folio read-only document verification modal"
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 rounded-lg transition-colors shadow-2xs whitespace-nowrap shrink-0"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Verify Layout</span>
            <span className="sm:hidden">Verify</span>
          </button>
        )}

        <button
          onClick={onExportDocx}
          disabled={isExporting}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 active:bg-blue-900 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors shadow-xs whitespace-nowrap shrink-0 disabled:opacity-60"
        >
          <FileDown className="w-4 h-4" />
          <span>{isExporting ? 'Generating DOCX...' : 'Export DOCX'}</span>
        </button>
      </div>
    </header>
  );
};
