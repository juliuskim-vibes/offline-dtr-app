package com.institutional.dtreporter.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.institutional.dtreporter.data.AppDatabase
import com.institutional.dtreporter.data.DtrDao
import com.institutional.dtreporter.data.DtrEntry
import com.institutional.dtreporter.util.ExportResult
import com.institutional.dtreporter.util.InstitutionalMetadata
import com.institutional.dtreporter.util.WordExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * UI representation of a day in the monthly schedule, merging persisted DB data with
 * calculated calendar metadata (day of week, auto weekend remarks).
 */
data class DayCardUiModel(
    val dateString: String,      // "YYYY-MM-DD"
    val dayOfMonth: Int,         // 1..31
    val dayOfWeekName: String,   // "Monday", "Tuesday", etc.
    val isWeekend: Boolean,      // Saturday or Sunday
    val isSaturday: Boolean,
    val isSunday: Boolean,
    val activities: String,
    val remarks: String,
    val photoPath: String?,
    val status: String,          // "Accomplished", "Leave", "Official Travel"
    val isCustomized: Boolean    // True if user explicitly edited
)

/**
 * Monthly statistics for quick dashboard overview.
 */
data class MonthlyStats(
    val totalDays: Int = 0,
    val accomplishedDays: Int = 0,
    val leaveDays: Int = 0,
    val travelDays: Int = 0,
    val weekendDays: Int = 0,
    val photosAttached: Int = 0
)

/**
 * State of the DOCX generation task.
 */
sealed interface ExportStatus {
    object Idle : ExportStatus
    object Exporting : ExportStatus
    data class Success(val filePath: String) : ExportStatus
    data class Error(val message: String) : ExportStatus
}

/**
 * Principal ViewModel orchestrating Room database queries, calendar math,
 * dialog state, and background Apache POI document exports.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val dtrDao: DtrDao = AppDatabase.getDatabase(application).dtrDao()

    // Currently selected Year & Month
    private val _selectedYearMonth = MutableStateFlow(YearMonth.now())
    val selectedYearMonth: StateFlow<YearMonth> = _selectedYearMonth.asStateFlow()

    // Institutional metadata
    private val _metadata = MutableStateFlow(InstitutionalMetadata())
    val metadata: StateFlow<InstitutionalMetadata> = _metadata.asStateFlow()

    // Export status
    private val _exportStatus = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
    val exportStatus: StateFlow<ExportStatus> = _exportStatus.asStateFlow()

    // Active day being edited in DailyEntryDialog
    private val _editingDay = MutableStateFlow<DayCardUiModel?>(null)
    val editingDay: StateFlow<DayCardUiModel?> = _editingDay.asStateFlow()

    // Filter status ("All", "Accomplished", "Leave", "Travel", "Weekdays")
    private val _filterQuery = MutableStateFlow("All")
    val filterQuery: StateFlow<String> = _filterQuery.asStateFlow()

    // Observe DB entries reactively whenever selectedYearMonth changes
    val monthlyEntries: StateFlow<List<DtrEntry>> = _selectedYearMonth
        .flatMapLatest { ym ->
            val monthPrefix = String.format(Locale.US, "%04d-%02d-%%", ym.year, ym.monthValue)
            dtrDao.getEntriesForMonth(monthPrefix)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Merge persistent DB entries with all days of the month (1..28/29/30/31)
    val daysList: StateFlow<List<DayCardUiModel>> = combine(
        _selectedYearMonth,
        monthlyEntries,
        _filterQuery
    ) { ym, entries, filter ->
        val daysInMonth = ym.lengthOfMonth()
        val entryMap = entries.associateBy { it.dayOfMonth }

        val allDays = (1..daysInMonth).map { day ->
            val localDate = LocalDate.of(ym.year, ym.month, day)
            val dayOfWeek = localDate.dayOfWeek
            val isSat = dayOfWeek == DayOfWeek.SATURDAY
            val isSun = dayOfWeek == DayOfWeek.SUNDAY
            val isWeekend = isSat || isSun

            val saved = entryMap[day]
            val dateKey = localDate.format(DateTimeFormatter.ISO_LOCAL_DATE)

            val activities = saved?.activities ?: ""
            val defaultRemark = when {
                isSat -> "SATURDAY"
                isSun -> "SUNDAY"
                else -> ""
            }
            val remarks = saved?.remarks?.takeIf { it.isNotBlank() } ?: defaultRemark
            val status = saved?.status ?: if (isWeekend) "Weekend" else "Accomplished"
            val photoPath = saved?.photoPath

            DayCardUiModel(
                dateString = dateKey,
                dayOfMonth = day,
                dayOfWeekName = dayOfWeek.name.take(3).lowercase(Locale.ROOT)
                    .replaceFirstChar { it.titlecase(Locale.ROOT) },
                isWeekend = isWeekend,
                isSaturday = isSat,
                isSunday = isSun,
                activities = activities,
                remarks = remarks,
                photoPath = photoPath,
                status = status,
                isCustomized = saved != null
            )
        }

        // Apply filtering
        when (filter) {
            "Weekdays" -> allDays.filter { !it.isWeekend }
            "Accomplished" -> allDays.filter { it.status == "Accomplished" && it.activities.isNotBlank() }
            "Leave" -> allDays.filter { it.status == "Leave" }
            "Official Travel" -> allDays.filter { it.status == "Official Travel" }
            "Photos" -> allDays.filter { !it.photoPath.isNullOrBlank() }
            else -> allDays
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calculate monthly statistics
    val monthlyStats: StateFlow<MonthlyStats> = combine(
        _selectedYearMonth,
        monthlyEntries
    ) { ym, entries ->
        val daysInMonth = ym.lengthOfMonth()
        val entryMap = entries.associateBy { it.dayOfMonth }

        var accomplished = 0
        var leaves = 0
        var travels = 0
        var weekends = 0
        var photos = 0

        for (day in 1..daysInMonth) {
            val date = LocalDate.of(ym.year, ym.month, day)
            val isWk = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY
            if (isWk) weekends++

            val entry = entryMap[day]
            if (entry != null) {
                if (entry.status == "Leave") leaves++
                else if (entry.status == "Official Travel") travels++
                else if (entry.activities.isNotBlank()) accomplished++

                if (!entry.photoPath.isNullOrBlank()) photos++
            }
        }

        MonthlyStats(
            totalDays = daysInMonth,
            accomplishedDays = accomplished,
            leaveDays = leaves,
            travelDays = travels,
            weekendDays = weekends,
            photosAttached = photos
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MonthlyStats()
    )

    fun setYearMonth(ym: YearMonth) {
        _selectedYearMonth.value = ym
    }

    fun previousMonth() {
        _selectedYearMonth.value = _selectedYearMonth.value.minusMonths(1)
    }

    fun nextMonth() {
        _selectedYearMonth.value = _selectedYearMonth.value.plusMonths(1)
    }

    fun setFilter(filter: String) {
        _filterQuery.value = filter
    }

    fun updateMetadata(newMeta: InstitutionalMetadata) {
        _metadata.value = newMeta
    }

    fun openEditDialog(day: DayCardUiModel) {
        _editingDay.value = day
    }

    fun dismissEditDialog() {
        _editingDay.value = null
    }

    /**
     * Persists or updates the DTR record into Room database on IO dispatcher.
     */
    fun saveEntry(
        dateString: String,
        dayOfMonth: Int,
        activities: String,
        remarks: String,
        status: String,
        photoPath: String?
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val entry = DtrEntry(
                date = dateString,
                dayOfMonth = dayOfMonth,
                activities = activities,
                remarks = remarks,
                status = status,
                photoPath = photoPath
            )
            dtrDao.insertOrUpdate(entry)
            _editingDay.value = null
        }
    }

    /**
     * Automatically tags all Saturdays and Sundays in the current month with
     * standard "SATURDAY" or "SUNDAY" remarks in the database.
     */
    fun autoTagWeekends() {
        viewModelScope.launch(Dispatchers.IO) {
            val ym = _selectedYearMonth.value
            val daysInMonth = ym.lengthOfMonth()
            val entriesToInsert = mutableListOf<DtrEntry>()

            for (day in 1..daysInMonth) {
                val date = LocalDate.of(ym.year, ym.month, day)
                val isSat = date.dayOfWeek == DayOfWeek.SATURDAY
                val isSun = date.dayOfWeek == DayOfWeek.SUNDAY

                if (isSat || isSun) {
                    val dateKey = date.format(DateTimeFormatter.ISO_LOCAL_DATE)
                    val existing = dtrDao.getEntryByDate(dateKey)
                    val remark = if (isSat) "SATURDAY" else "SUNDAY"

                    if (existing == null) {
                        entriesToInsert.add(
                            DtrEntry(
                                date = dateKey,
                                dayOfMonth = day,
                                activities = "",
                                remarks = remark,
                                status = "Weekend",
                                photoPath = null
                            )
                        )
                    }
                }
            }

            if (entriesToInsert.isNotEmpty()) {
                dtrDao.insertAll(entriesToInsert)
            }
        }
    }

    /**
     * Triggers Apache POI export in background coroutine on Dispatchers.IO.
     */
    fun exportToWordDocument(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            _exportStatus.value = ExportStatus.Exporting
            val result: ExportResult = WordExporter.exportMonthlyReport(
                context = context,
                yearMonth = _selectedYearMonth.value,
                savedEntries = monthlyEntries.value,
                metadata = _metadata.value
            )
            if (result.isSuccess && result.filePath != null) {
                _exportStatus.value = ExportStatus.Success(result.filePath)
            } else {
                _exportStatus.value = ExportStatus.Error(result.errorMessage ?: "Export failed.")
            }
        }
    }

    fun dismissExportStatus() {
        _exportStatus.value = ExportStatus.Idle
    }
}
